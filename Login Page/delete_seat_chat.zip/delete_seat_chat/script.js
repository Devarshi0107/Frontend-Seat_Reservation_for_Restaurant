// document.addEventListener('DOMContentLoaded', function () {
//     const seats = document.querySelectorAll('.seat input[type="checkbox"]');
  
//     // Add click event listeners to each seat
//     seats.forEach(seat => {
//       seat.addEventListener('click', function () {
//         const seatId = seat.id;
//         const seatLabel = seat.nextElementSibling.textContent;
        
//         if (seat.checked) {
//           console.log(`Seat ${seatLabel} (${seatId}) selected`);
//           reserveSeat(seatId); // Call function to reserve the seat
//         } else {
//           console.log(`Seat ${seatLabel} (${seatId}) deselected`);
//           releaseSeat(seatId); // Call function to release the seat
//         }
//       });
//     });
  
//     // Function to reserve the seat (You need to implement this)
//     function reserveSeat(seatId) {
//       // Add your logic to reserve the seat here
//     }
  
//     // Function to release the seat (You need to implement this)
//     function releaseSeat(seatId) {
//       // Add your logic to release the seat here
//     }
//   });
  

document.addEventListener('DOMContentLoaded', function () {
    const seats = document.querySelectorAll('.seat input[type="checkbox"]');
    const numPeopleSelect = document.getElementById('numPeople');
    const timeSlotSelect = document.getElementById('timeSlot');
    const bookBtn = document.getElementById('bookBtn');
  
    let selectedSeats = [];
  
    // Add click event listeners to each seat
    seats.forEach(seat => {
      seat.addEventListener('click', function () {
        const seatId = seat.dataset.seat;
        const numPeople = parseInt(numPeopleSelect.value);
  
        if (seat.checked) {
          if (selectedSeats.length >= numPeople) {
            seat.checked = false;
            alert(`You can only select ${numPeople} seats.`);
            return;
          }
          selectedSeats.push(seatId);
        } else {
          selectedSeats = selectedSeats.filter(selectedSeat => selectedSeat !== seatId);
        }
      });
    });
  
    // Function to handle seat booking
    bookBtn.addEventListener('click', function () {
      const numPeople = parseInt(numPeopleSelect.value);
      const timeSlot = timeSlotSelect.value;
  
      if (selectedSeats.length !== numPeople) {
        alert(`Please select ${numPeople} seats.`);
        return;
      }
  
      // Perform booking logic here (e.g., notify user, update database, etc.)
      alert(`Seats ${selectedSeats.join(', ')} booked for ${numPeople} people at ${timeSlot}.`);
    });
  });
  